<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use Session;
use Srmklive\PayPal\Services\ExpressCheckout;
class ProductController extends Controller
{

	public function payNow(Request $request)
	{
      $product=Product::find($request->pid);
      //return $product;

		$data = [];

        $data['items'] = [

            [

                'name' =>$product->product_name,

                'price' =>$product->price,

                'desc'  =>$product->description,

                'qty' => 1

            ]

        ];

        $data['invoice_id'] = time();
        $data['invoice_description'] = "Order #{$data['invoice_id']} Invoice";
        $data['return_url'] = route('payment.success');
        $data['cancel_url'] = route('payment.cancel');
        $data['total'] = $product->price;

        //dd($data);
        $provider = new ExpressCheckout;
        $response = $provider->setExpressCheckout($data);
        $response = $provider->setExpressCheckout($data, true);
        
       

        return redirect($response['paypal_link']);
	}

	    public function cancel(Request $request)

    {
    	 $provider = new ExpressCheckout;
        $response = $provider->getExpressCheckoutDetails($request->token);
        dd($response);

    }

 
    public function success(Request $request)

    {
         $provider = new ExpressCheckout;
        $response = $provider->getExpressCheckoutDetails($request->token);

  

        if (in_array(strtoupper($response['ACK']), ['SUCCESS', 'SUCCESSWITHWARNING'])) {

            dd('Your payment was successfully. You can create success page here.');

        }

  

        dd('Something is wrong.');

    }

	 public function index(Request $request)
	 {
	 	
	 	 $products=Product::where('id','>','0');

	 	 if ($request->has('search') && $request->get('search')!='') {
	 	 	$keyword=$request->get('search');
	 	$products=$products->where(function ($query) use($keyword) {
        $query->where('id', 'like', '%' . $keyword . '%')
           ->orWhere('product_name', 'like', '%' . $keyword . '%')
           ->orWhere('product_code', 'like', '%' . $keyword . '%')
           ->orWhere('description', 'like', '%' . $keyword . '%')
           ->orWhere('price', 'like', '%' . $keyword . '%')
           ->orWhere('created_at', 'like', '%' . $keyword . '%');
      });
	 	}

	 	$products=$products->paginate(10);



	 	 return view('home',compact('products'));
	 }
     public function addProduct()
     {
     	  

     	  return view('add-product',compact('products'));
     }

     public function saveProduct(Request $request)
     {
         $product=new Product();
         $this->validate($request,[
         'product_name'=>'required',
         'price' => 'required|regex:/^\d+(\.\d{1,2})?$/',
         'description'=>'required',
         'product_code'=>'required|unique:products',
         'image' => 'mimes:jpeg,jpg,png,gif|required'
         ]);
         $product->product_name=$request->product_name;
         $product->description=$request->description;
         $product->price=$request->price;
         $product->product_code=$request->product_code;
        $rarefile = $request->file('image');    
        if($rarefile!=''){
        $raupload = public_path() .'/img/product-image/';
        $rarefilename=time().'.'.$rarefile->getClientOriginalName();
        $success=$rarefile->move($raupload,$rarefilename);
        $product->image = $rarefilename;
        }
         $product->save();

         Session::flash('msg','Product Saved Suceessfully');

         return back();
     }
}
